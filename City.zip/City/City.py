import mcpi.minecraft as minecraft
import time
import random

mc = minecraft.Minecraft.create()

CELL_SIZE = (20, 20)

MATERIALS = {
    "glass_office": {"wall": 155, "glass": 95, "floor": 1},
    "brick_house": {"wall": 49, "glass": 102, "floor": 4},
    "clay_tower": {"wall": 159, "glass": 95, "floor": 42},
    "wooden_house": {"wall": 17, "glass": 95, "floor": 5}
}

BUILDING_HEIGHTS = [12, 16, 20, 24, 28]
STYLES = ["glass_office", "brick_house", "clay_tower", "wooden_house"]

CITY_MAP = [

    ['B', 'R', 'B', 'R', 'B', 'R', 'B'],
    ['R', 'P', 'R', 'P', 'R', 'P', 'R'],
    ['B', 'R', 'B', 'R', 'B', 'R', 'B'],
    ['R', 'P', 'R', 'A', 'R', 'P', 'R'],
    ['B', 'R', 'B', 'R', 'B', 'R', 'B'],
    ['H', 'H', 'H', 'H', 'H', 'H', 'H'],
    ['B', 'R', 'B', 'R', 'B', 'R', 'B']
]

BUILDINGS = []

car1_pos = [0, 0, 0]
car2_pos = [0, 0, 0]
CAR_SPEED = 0.05
last_car_move = 0

def draw_car(x, y, z, color_block, direction):

    mc.setBlocks(x, y + 1, z, x + 4, y + 1, z + 2, color_block)
    mc.setBlocks(x + 1, y + 2, z, x + 3, y + 2, z + 2, color_block)

    mc.setBlocks(x + 1, y + 2, z, x + 3, y + 2, z, 20)
    mc.setBlocks(x + 1, y + 2, z + 2, x + 3, y + 2, z + 2, 20)

    if direction == 1:
        mc.setBlock(x + 4, y + 2, z + 1, 20)
        mc.setBlock(x + 4, y + 1, z, 89)
        mc.setBlock(x + 4, y + 1, z + 2, 89)

    else:
        mc.setBlock(x, y + 2, z + 1, 20)
        mc.setBlock(x, y + 1, z, 89)
        mc.setBlock(x, y + 1, z + 2, 89)

def erase_car(x, y, z):
    mc.setBlocks(x, y + 1, z, x + 4, y + 2, z + 2, 0)


def build_highway(start_x, y, start_z, width, length):

    mc.setBlocks(start_x, y - 1, start_z, start_x + width, y - 1, start_z + length, 98)
    mc.setBlocks(start_x + 2, y - 1, start_z + 2, start_x + width - 2, y - 1, start_z + length - 2, 1)

    center_z = start_z + length // 2
    for i in range(start_x + 2, start_x + width - 2, 4):
        mc.setBlocks(i, y - 1, center_z, i + 1, y - 1, center_z, 155)

    build_streetlight(start_x + 2, y, start_z + 2)
    build_streetlight(start_x + width - 2, y, start_z + 2)
    build_streetlight(start_x + 2, y, start_z + length - 2)
    build_streetlight(start_x + width - 2, y, start_z + length - 2)


def origin(distance, width, length):
    pos = mc.player.getTilePos()
    rot = mc.player.getRotation() % 360

    bx, bz = pos.x, pos.z

    if 315 <= rot or rot < 45:
        bx = pos.x - (width // 2)
        bz = pos.z + distance

    elif 45 <= rot < 135:
        bx = pos.x - distance - width
        bz = pos.z - (length // 2)

    elif 135 <= rot < 225:
        bx = pos.x - (width // 2)
        bz = pos.z - distance - length

    elif 225 <= rot < 315:
        bx = pos.x + distance
        bz = pos.z - (length // 2)

    return minecraft.Vec3(bx, pos.y, bz)


def clean():
    mc.postToChat('[Clean] - Cleaning start')
    pos = mc.player.getTilePos()
    a = 200

    mc.setBlocks(pos.x - a, pos.y - 1, pos.z - a, pos.x + a, pos.y - 1, pos.z + a, 2)
    mc.setBlocks(pos.x - a, pos.y, pos.z - a, pos.x + a, pos.y + a, pos.z + a, 0)
    mc.postToChat('[Clean] - Cleaning complete')

def build_park(start_x, y, start_z, width, length):
    mc.setBlocks(start_x, y - 1, start_z, start_x + width, y - 1, start_z + length, 2)
    mc.setBlock(start_x + 2, y, start_z + 2, 6)
    mc.setBlock(start_x + width - 2, y, start_z + 2, 6)
    mc.setBlock(start_x + 2, y, start_z + length - 2, 6)
    mc.setBlock(start_x + width - 2, y, start_z + length - 2, 6)

    center_x = start_x + (width // 2)
    center_z = start_z + (length // 2)

    mc.setBlocks(center_x - 2, y, center_z - 2, center_x + 2, y, center_z + 2, 1)
    mc.setBlocks(center_x - 1, y, center_z - 1, center_x + 1, y, center_z + 1, 8)

    mc.setBlocks(center_x, y + 1, center_z, center_x, y + 3, center_z, 1)
    mc.setBlock(center_x, y + 4, center_z, 89)
    mc.setBlock(center_x, y + 5, center_z, 8)

    left_x = center_x - 3
    right_x = center_x + 3
    top_z = center_z - 3
    bottom_z = center_z + 3

    for x in range(left_x, right_x + 1):
        mc.setBlock(x, y, top_z, random.choice([37, 38]))
        mc.setBlock(x, y, bottom_z, random.choice([37, 38]))

    for z in range(top_z + 1, bottom_z):
        mc.setBlock(left_x, y, z, random.choice([37, 38]))
        mc.setBlock(right_x, y, z, random.choice([37, 38]))


def attraction_park(start_x, y, start_z, width, length):
    mc.setBlocks(start_x, y - 1, start_z, start_x + width, y - 1, start_z + length, 2)

    center_x = start_x + (width // 2)
    center_z = start_z + (length // 2)
    #Круглая площадь под карусель
    mc.setBlocks(center_x - 4, y, center_z - 4, center_x + 4, y, center_z + 4, 155)
    #колонна карусели
    mc.setBlocks(center_x, y + 1, center_z, center_x, y + 5, center_z, 17)
    #крыша карусели
    mc.setBlocks(center_x - 4, y + 6, center_z - 4, center_x + 4, y + 6, center_z + 4, 45)
    mc.setBlocks(center_x - 2, y + 7, center_z - 2, center_x + 2, y + 7, center_z + 2, 41)
    mc.setBlock(center_x, y + 8, center_z, 89)
    #"Качели" на карусели
    mc.setBlock(center_x - 2, y + 1, center_z - 2, 85)
    mc.setBlock(center_x + 2, y + 1, center_z - 2, 85)
    mc.setBlock(center_x - 2, y + 1, center_z + 2, 85)
    mc.setBlock(center_x + 2, y + 1, center_z + 2, 85)
    # Дорожки
    mc.setBlocks(start_x + 1, y, center_z - 1, center_x - 5, y, center_z + 1, 155)
    mc.setBlocks(center_x + 5, y, center_z - 1, start_x + width - 1, y, center_z + 1, 155)
    mc.setBlocks(center_x - 1, y, start_z + 1, center_x + 1, y, center_z - 5, 155)
    mc.setBlocks(center_x - 1, y, center_z + 5, center_x + 1, y, start_z + length - 1, 155)
    # Скамейки
    mc.setBlocks(start_x + 2, y, start_z + 2, start_x + 4, y, start_z + 2, 85)
    mc.setBlocks(start_x + 2, y, start_z + 3, start_x + 4, y, start_z + 3, 126)
    mc.setBlocks(start_x + width - 4, y, start_z + 2, start_x + width - 2, y, start_z + 2, 85)
    mc.setBlocks(start_x + width - 4, y, start_z + 3, start_x + width - 2, y, start_z + 3, 126)
    mc.setBlocks(start_x + 2, y, start_z + length - 2, start_x + 4, y, start_z + length - 2, 85)
    mc.setBlocks(start_x + 2, y, start_z + length - 3, start_x + 4, y, start_z + length - 3, 126)
    mc.setBlocks(start_x + width - 4, y, start_z + length - 2, start_x + width - 2, y, start_z + length - 2, 85)
    mc.setBlocks(start_x + width - 4, y, start_z + length - 3, start_x + width - 2, y, start_z + length - 3, 126)

def build_building(start_x, y, start_z, width, length, height, style_name, door_sides):
    mat = MATERIALS[style_name]
    # Ставим сплошной куб
    mc.setBlocks(start_x, y, start_z, start_x + width, y + height, start_z + length, mat["wall"])
    # Добавляем внутреннее пространство
    mc.setBlocks(start_x + 1, y + 1, start_z + 1, start_x + width - 1, y + height - 1, start_z + length - 1, 0)

    wall = mat["wall"]
    floor_block = mat["floor"]

    # Крыша
    mc.setBlocks(start_x, y + height + 1, start_z, start_x + width, y + height + 1, start_z + length, 113)
    mc.setBlocks(start_x + 1, y + height + 1, start_z + 1, start_x + width - 1, y + height + 1, start_z + length - 1, 0)

    for floor_y in range(0, height, 4):
        # Пол
        mc.setBlocks(start_x, y + floor_y, start_z, start_x + width, y + floor_y, start_z + length, floor_block)

        if floor_y > 0:
            below_floor_index = (floor_y - 4) // 4
            if below_floor_index % 2 == 0:
                hole_x1 =  start_x + width - 3
                hole_x2 = start_x + width - 2
            else:
                hole_x1 = start_x + 1
                hole_x2 = start_x + 2

            mc.setBlocks(hole_x1, y + floor_y, start_z + 2, hole_x2, y + floor_y, start_z + 4, 0)

        if floor_y < height - 4:
            current_floor_index = floor_y // 4
            if current_floor_index % 2 == 0:
                stair_x1 = start_x + width - 3
                stair_x2 = start_x + width - 2
            else:
                stair_x1 = start_x + 1
                stair_x2 = start_x + 2

            stair_z = start_z + 2

            # Первая ступенька
            mc.setBlock(stair_x1, y + floor_y + 1, stair_z, 53, 2)
            mc.setBlock(stair_x2, y + floor_y + 1, stair_z, 53, 2)
            # Вторая ступенька
            mc.setBlock(stair_x1, y + floor_y + 2, stair_z + 1, 53, 2)
            mc.setBlock(stair_x2, y + floor_y + 2, stair_z + 1, 53, 2)
            # Третья ступенька
            mc.setBlock(stair_x1, y + floor_y + 3, stair_z + 2, 53, 2)
            mc.setBlock(stair_x2, y + floor_y + 3, stair_z + 2, 53, 2)

    # Добавляем окна
        glass = mat["glass"]
        # Ближняя стена
        mc.setBlocks(start_x + 2, y + floor_y + 2, start_z, start_x + width - 2, y + floor_y + 2, start_z, glass)
        # Дальняя стена
        mc.setBlocks(start_x + 2, y + floor_y + 2, start_z + length, start_x + width - 2, y + floor_y + 2, start_z + length, glass)
        # Левая стена
        mc.setBlocks(start_x, y + floor_y + 2, start_z + 2, start_x, y + floor_y + 2, start_z + length - 2, glass)
        # Правая стена
        mc.setBlocks(start_x + width, y + floor_y + 2, start_z + 2, start_x + width, y + floor_y + 2, start_z + length - 2, glass)

    # Добавляем двери
    for side in door_sides:
        if side == "front":
            door_x = start_x + width // 2
            mc.setBlocks(door_x, y + 1, start_z + length, door_x, y + 2, start_z + length, 0)
            mc.setBlocks(door_x, y + 1, start_z + length, door_x, y + 2, start_z + length, 64)

        elif side == "back":
            door_x = start_x + width // 2
            mc.setBlocks(door_x, y + 1, start_z, door_x, y + 2, start_z, 0)
            mc.setBlocks(door_x, y + 1, start_z, door_x, y + 2, start_z, 64)


def build_streetlight(start_x, y, start_z):
    mc.setBlock(start_x, y, start_z, 155)
    mc.setBlock(start_x, y + 1, start_z, 155)
    mc.setBlock(start_x, y + 2, start_z, 89)


def build_path(start_x, y, start_z, width, length):
    mc.setBlocks(start_x, y - 1, start_z, start_x + width, y - 1, start_z + length, 98)  # Тротуар
    mc.setBlocks(start_x + 2, y - 1, start_z + 2, start_x + width - 2, y - 1, start_z + length - 2, 1)  # Асфальт
    # Разметка
    mc.setBlocks(start_x + width // 2, y - 1, start_z + 2, start_x + width // 2, y - 1, start_z + length - 2, 155)
    # Размещаем фонари на дорожках
    build_streetlight(start_x + 2, y, start_z + 2)
    build_streetlight(start_x + width - 2, y, start_z + 2)
    build_streetlight(start_x + 2, y, start_z + length - 2)
    build_streetlight(start_x + width - 2, y, start_z + length - 2)

def forest(start_x, y, start_z):
    for i in range(0, 140, 4):
        mc.setBlock(start_x - 3, y, start_z + i, 6)

def generate_city(pos):

    cell_w, cell_l = CELL_SIZE
    mc.postToChat("[City] Generating start...")
    for row_idx, row in enumerate(CITY_MAP):
        for col_idx, cell_type in enumerate(row):
            start_x = pos.x + (col_idx * cell_w)
            start_z = pos.z + (row_idx * cell_l)
            if cell_type == 'R':
                build_path(start_x, pos.y, start_z, cell_w, cell_l)
            elif cell_type == 'B':
                door_sides = []
                h = random.choice(BUILDING_HEIGHTS)
                style = random.choice(STYLES)
                if row_idx > 0 and CITY_MAP[row_idx - 1][col_idx] == 'R':
                    door_sides.append("back")
                if row_idx < len(CITY_MAP) - 1 and CITY_MAP[row_idx + 1][col_idx] == 'R':
                    door_sides.append("front")
                b_start_x = start_x + 2
                b_start_z = start_z + 2
                b_width = cell_w - 4
                b_length = cell_l - 4

                build_building(start_x + 2, pos.y, start_z + 2, cell_w - 4, cell_l - 4, h, style, door_sides)

                BUILDINGS.append((b_start_x, pos.y, b_start_z, b_width, b_length, h))
                if row_idx == 0 and cell_type == 'B':
                    for i in range(start_x, start_x + cell_w, 2):
                       mc.setBlock(i, pos.y, start_z - 2, random.choice([37, 38]))

            elif cell_type == 'P':
                build_park(start_x, pos.y, start_z, cell_w, cell_l)

            elif cell_type == 'A':
                attraction_park(start_x, pos.y, start_z, cell_w, cell_l)
            elif cell_type == 'H':
                build_highway(start_x, pos.y, start_z, cell_w, cell_l)
        forest(pos.x, pos.y, pos.z)

    global car1_pos, car2_pos 

    road_y = pos.y - 1
    road_z_center = pos.z + (5 * cell_l) + (cell_l // 2)
    car1_pos = [pos.x + 5, road_y, road_z_center + 3]
    car2_pos = [pos.x + (7 * cell_w) - 15, road_y, road_z_center - 4]

    mc.postToChat("[City] Generate complete!")

def spawn_secret():
    mc.postToChat("[Secret] Searching for a hidden spot...")
    bx, by, bz, bw, bl, bh = random.choice(BUILDINGS)

    num_floors = bh // 4
    random_floor = random.randint(0, num_floors - 1)

    chest_y = by + (random_floor * 4) + 1
    chest_x = bx + random.randint(2, bw - 2)
    chest_z = bz + random.randint(5, bl - 2)

    mc.setBlock(chest_x, chest_y, chest_z, 54)
    mc.setBlock(chest_x, chest_y - 1, chest_z, 41)
    mc.setBlock(chest_x + 1, chest_y, chest_z, 50)
    mc.setBlock(chest_x - 1, chest_y, chest_z, 50)

    mc.postToChat("[Secret] Treasure hidden!")


mc.postToChat("===COMMAND MENU===")
mc.postToChat("Type 'city' to start.")
mc.postToChat("Type 'clean' to cleaning place.")

while True:
    if car1_pos and car2_pos:
        current_time = time.time()
        if current_time - last_car_move > CAR_SPEED:
            erase_car(car1_pos[0], car1_pos[1], car1_pos[2])
            erase_car(car2_pos[0], car2_pos[1], car2_pos[2])

            car1_pos[0] += 1
            car2_pos[0] -= 1

            if car1_pos[0] > mc.player.getTilePos().x + (7 * CELL_SIZE[0]):
                car1_pos[0] = mc.player.getTilePos().x

            if car2_pos[0] < mc.player.getTilePos().x:
                car2_pos[0] = mc.player.getTilePos().x + (7 * CELL_SIZE[0])

            draw_car(car1_pos[0], car1_pos[1], car1_pos[2], 159, 1)
            draw_car(car2_pos[0], car2_pos[1], car2_pos[2], 35, -1)

            last_car_move = current_time


    chat_events = mc.events.pollChatPosts()
    for event in chat_events:
        if event.message.lower().strip() == "city":
            city_start = origin(distance=10, width=140, length=140)
            generate_city(city_start)
        elif event.message.lower().strip() == "clean":
            clean()
        elif event.message.lower().strip() == "secret":
            spawn_secret()

    time.sleep(0.1)